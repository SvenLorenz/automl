# Loads data stored in McNemarTest.csv
# @param fl (`character(1)`): Path of csv file
# @return (`data.table()`): labels, prediction1, prediction2
load_data_MNTest = function(fl = "") {  # FIXME: correct path
  stop("To Implement")
}

# Loads data stored in TMStTestData.csv
# @param fl (`character(1)`): Path of csv file
# @return (`data.table()`) with columns y1, y2
load_data_TMStTest = function(fl = "") {  # FIXME: correct path
  stop("To Implement")
}

# Loads data stored in FTestData.csv
# @param fl (`character(1)`): Path of csv file
# @return (`matrix(numeric())`) with datasets in rows and algorithms in columns
load_data_FTestData = function(fl = "") {  # FIXME: correct path
  stop("To Implement")
}

