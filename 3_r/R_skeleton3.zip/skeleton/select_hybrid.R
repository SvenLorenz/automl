# Use pairwise classification to predict which algorithm will outperform the others.
# Select the algorithm with the most wins.
# @param test_instances (`character()`): Instance names to predict
# @param run_df (`data.table()`): data.table containing all instance runtime data
# @param feature_df (`data.table()`): data.table containing all trainings instance feature data
# @param test_feature_df (`data.table()`): data.table containing all test instance feature data
# @return (`data.table(instance_id, algorithm)`): data.table with selected algorithm per instance
select_hybrid = function(test_instances, run_df, feature_df, test_feature_df) {
  stop("To Implement")
}
