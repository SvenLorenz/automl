# Use any regression model to predict the performance for each algorithm individually.
# Select the algorithm with smallest predicted runtime.
# @param test_instances (`character()`): Instance names to predict
# @param run_df (`data.table()`): data.table containing all instance runtime data
# @param feature_df (`data.table()`): data.table containing all trainings instance feature data
# @param test_feature_df (`data.table()`): data.table containing all test instance feature data
# @return (`data.table(instance_id, algorithm)`): data.table with selected algorithm per instance
select_individual = function(test_instances, run_df, feature_df, test_feature_df, learner) {
  stop("To Implement")
}
