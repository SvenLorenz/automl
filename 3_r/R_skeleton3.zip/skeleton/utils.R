# Executes the algorithm selection for each fold, defined in `cv`.
# @param run_df (`data.table`): data.table containing all training runtime data (i.e. y_train)
# @param features (`data.table`): feature values of the instances
# @param cv (`data.table`): Predefined splits
# @param selector_fun (`function(test_instances, run_df, feature_df, test_feature_df)`): either `select_individual` or `select_hybrid`
# @return (`character()`): named character vector of selected algorithm per instance
select_algorithms = function(run_df, features, cv, selector_fun) {
  stop("To Implement")
}

# Calculate Performance of Selection strategy
# @param selected (`character()`): named character vector of selected algorithm per instance
# @param run_df (`data.table`): data.table containing all training runtime data (i.e. y_train)
# @param cutoff (`double(1)`): The used cutoff as a double
# @param par (`integer(1)`): The penalization factor (default = 10) if runtime >= cutoff then runtime = PAR * cutoff
# @return (`double(1)`): Average perfromance of the selected algorithms
calculate_performance = function(selected, run_df, cutoff, par = 10L) {
  stop("To Implement")
}
