# Get the performance of the single best algorithm
# @param run_df (`data.table`): data.table containing all training runtime data (i.e. y_train)
# @param cutoff (`double(1)`): The used cutoff as a double
# @param par (`integer(1)`): The penalization factor (default = 10) if runtime >= cutoff then runtime = PAR * cutoff
# @return single_best_perf (`double(1)`)
get_single_best = function(run_df, cutoff, par = 10L) {
  stop("To Implement")
}

# Get the virtual best performance
# @param run_df (`data.table`): data.table containing all training runtime data (i.e. y_train)
# @param cutoff (`double(1)`): The used cutoff as a double
# @param par (`integer(1)`): The penalization factor (default = 10) if runtime >= cutoff then runtime = PAR * cutoff
# @return oracle_perf (`double(1)`)
get_virtual_best = function(run_df, cutoff, par = 10L) {
  stop("To Implement")
}
